export default {
  dsn: process.env.SENTRY_DSN,
};
